 #if some_condition:
    # DO SOMETHING HERE
#else:
    # DO SOMETHING ELSE HERE
    
  #ex.  some_variable =
    
    #if some_variable == 0:
    
    #print("Hello World!")
    
#if some_condition:
    # DO SOMETHING HERE RELATED TO THE IF CONDITION
#elif another_condition:
    # DO SOMETHING HERE RELATED TO THE ELIF CONDITION
#else:
    # DO SOMETHING HERE IF NONE OF THE ABOVE CONDITIONS ARE TRUE
    
name = input("What is your name?").capitalize()
#ex. if input("What is your name?") == "Miles":
#print("Your name is Miles!")
elif name == "John":
    print ("That's a boring name!")
elif name == "Mary":
    print("My grandma was also a Mary.")
else:
    print("Your bane is weird.")
    


