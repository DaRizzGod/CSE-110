
Story = True 
while Story: 
    intro = input('Welcome to the adventure! Do you dare join?')
    if intro.capitalize() == 'hey':
        story:'A new hero arise from his slumber and has no idea where he is and that the only thing he does know is that his consciousness has a journalthat says “THANK PROGRAMMER! He has no idea what it means but proceeds to leave the place where he slumbered.'
        print(story)
        break
    else: intro.capitalize() =='bye'
    story = 'From the villian: This is my story and that you will enjoy it! This is what I like to call force family fun. I think that everyone and their mom needs it.'
    print(story)
    break
Story = False

Direction = True
while Direction:
    go = input('Does he talk to the villian?')
    if go.capitalize() != 'yes':
        story = "Welp! the Vilian and our hero does indeed talk and that they end up finding out a lot about each other but they still hate each other because this is stil a story after all."  
        print(story)
        break
    else: go.captialize() != 'no'
    story = 'This is a story after all and that they the villian plus the hero still hate each other and that they will meet eacch other later in the story.'
    print(story)
    break
Direction = False

Train = True
while Train:
    ex = input('Does he embark on the train?')
    if ex.captialize() == 'yes':
        story:'He hops on the train and makes it to merlin place and starts to talking to him about what is going on. Merlin then proceeds to explain to him that a lot has happened since he was gone and that merlin brings out a book which our hero and learned a lot.'
        print(story)
        break
    else: ex.capitalize() == 'no'
    story: "He doesn't hop on the train and instead, he thinks he can walk to Merlins place which does and by the time he arrives. That merlin is already asleep so our hero decides to find a spot and sleep for night hoping that no one comes to him alive."
    print(story)
    break
Train = False

Journey = True
while Journey:
    fro  = input('Do you accept or not accept this journey?')
    if fro.captialize() == 'yes' :
        story = 'When you do that you agree to the terms and conditions that their is no going back. It Victory or defeat.'
        print(story)
    else: fro.captialize() =='no'  
    story = 'The Villian decides to intervine and come out of the portal and swallows the hero to depth of the earth.'
    print(story)
    break
Journey = False

Earth = True
while Earth:
    Aqua = input('How deep do you get into the earth?')
    if Aqua.capitalize() == 'yes' :
        story = 'Your get into the core but luckily your earthproof and can get into the core. While the villian has to put up a shield but that his shield isnt long.'
        print(story)
        break
    else: Aqua.capitalize() == 'no'
    story = 'The villian realizing that he has the upper hand in space will fight in the space and that our hero will live shortly in space.'
    print(story)
    break
Earth = False

Ending = True 
while Ending:
    Farewell = input('How do you think the story is going to end?')
    if Farewell.capitalize() == 'yes' :
        story = 'Well what ends up happening is that our hero actually survives but that the villian does not survive but transforms into a giant monster that will be told for another day.'
        print(story)
        break
    else: Farewell.capitalize() == 'no'
    story = 'The villian survives and that our hero dies but in the process that our villian creates many worlds to the point that  the story will be also told for another day.'
    print(story)
    break
Ending = False
    
    
    