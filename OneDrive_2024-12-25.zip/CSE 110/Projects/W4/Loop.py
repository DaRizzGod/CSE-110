# ex 1
# number = 0

# # Keep looping as long as the number is less than 10
# while number < 10:
#     number = int(input("Give me a number less than 10: "))

# print("Finished with the loop") 

# ex 2
# # Start with the number 1
# number = 1
# # Keep looping as long as the number is less than or equal to 5
# while number <= 5:
#   # Display the number
#   print(f"The number is: {number}")
 
#   # Update the number to be one more than it was
#   number = number + 1 
# print("Finished with the loop")

