def display_regular(word):
    print(word)
    
def display_uppercase(word):
    print(word.upper())
    
def display_lowercase(word):
    print(word.lower())
    
word = input('What is your message?')

display_regular(word)
display_uppercase(word)
display_lowercase(word)

    