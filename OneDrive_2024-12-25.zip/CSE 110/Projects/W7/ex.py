# def your_function_name():

# def print_message():
#     print('Hello CSE 110 World!')
    
# print_message()

# print_message()

# def print_double(value):
#     double_value = value * 2
#     print(double_value)
    
#     print_double(12)
#     print_double(3)
#     print_double(42)
    
# def get_double(value):
#     double_value = value * 2
#     return double_value
    
#     new_number = get_double(4)

# This is an error

# def get_double(value):
#     double_value = value * 2
#     return double_value

# new_number = get_double(4)

# print(double_value)

# def print_message(the_message):
#     print(the_message)
    
# the_message = "Message 1"
# print_message(the_message)

# user_message = "Message 2"
# print_message(user_message)

# def get_square(value):
#     return value * value
    
# my_square = get_square(12)

# print(my_square)

def length_plus(name, number):
    return len(name) + number

print(length_plus('miles',10))

