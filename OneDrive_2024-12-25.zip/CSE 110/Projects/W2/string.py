first_name = 'Miles'
last_name = 'Jo'

output = 'Hello, {} {}!'.format(first_name, last_name)
print(output)

print('Hello,', first_name, last_name,'!')

output = 'Hello, {0} {1}'. format (first_name, last_name)
print(output)

output = f'Hello, {first_name} {last_name}!'
print(output)