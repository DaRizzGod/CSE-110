#first_num = input('How_old_are_you?')
#second_num = input('Please_add_1_to_your_age')
#print(float(first_num) + float(second_num))  

#cartons = int(input('How_many_egg_cartons_do_you_have?'))
#print(f"You have {cartons * 12} eggs!")

#first_num = input('How_many_cookies_do_you_have?')
#second_num = input('How_many_people_are_there?')
#print(float(first_num) / float(second_num))


