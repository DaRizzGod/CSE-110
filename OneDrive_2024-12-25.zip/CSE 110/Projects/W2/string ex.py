words = 'the cat IN THE hat'
print = 'miles'

# words = words.lower()
# words_lower = words.lower()

print(words.lower())
# print(words.upper())
# print(words.capitalize())
# print('the cat IN THE hat' .upper())
# print('There are '+words.count(' ')+' spaces in the phrase.')

# print(f'{name.capitalize()}')