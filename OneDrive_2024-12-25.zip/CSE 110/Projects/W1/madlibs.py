#The other day, I was really in trouble. 
#It all started when I saw a very[adjective] [animal] [verb] down the hallway.
#"[exclamation]!" I yelled. 
#But all I could think to do was to [verb] over and over. 
#Miraculously,that caused it to stop, but not before it tried to [verb]
#right in front of my family.

print("Please asnwer the prompt below:")
print()
Pural_noun = input("Please enter a adjective")
Adjective =input("Please enter a verb")
Verb = input("Please enter a animal")
Adjective =input("Please enter a verb")
Noun = input("Please enter a exclamation")
print("--------------------------------")
print(f"{Adjective.lower()})")
print(f"{'Plural_noun'.lower()}")
print(f"{Adjective.lower()})")
print(f"{Verb.lower()}")
print(f"{Noun.capitalize()}")

