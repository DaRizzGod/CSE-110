# Color

# Please type your favoite color 
favorite_color = input("Enter a favorite color: ")

# Repeat the favorite color back to the user
print ("favorite_color")

# Print "Your favorite color is" back to the user
print(f'Your favorite_color is {favorite_color}')

# Food

# Please type your least favorite food
least_favorite_food = input("Enter least favorite food")

# Repeat least favorite food back to the user
print("least_favorite_food")

# Print"Least favorite food is" back to the user
print(f"Least_favorite_food is {least_favorite_food}")

