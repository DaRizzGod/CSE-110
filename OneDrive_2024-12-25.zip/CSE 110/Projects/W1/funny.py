# Ask the user for a funny quote or phrase.
funny_quote = input("Enter a funny phrase")

# Repeat the funny quote or phrase back to the user.
print("funny_quote")

# Print the words "Is there an echo in here?" back to the user
print("Ihes there an echo in there")